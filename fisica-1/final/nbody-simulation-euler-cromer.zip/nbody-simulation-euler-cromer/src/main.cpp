#include "../include/body.hpp"
#include "../include/vectors_operations.hpp"
#include <SFML/Graphics.hpp>
#include <array>
#include <iomanip>
#include <iostream>
#include <omp.h>
#include <random>
#include <sstream>

const int number_bodies = 20;
constexpr double GRAVITATIONAL_CONSTANT = 1;
const double DELTA_T = 0.0001;
const double CUTTOF = 500;
const double SOFTENING = 1.0;
const int width = 500, height = 500;

void calcular(std::array<Body, number_bodies> &);
double calcular_energia_total(const std::array<Body, number_bodies> &bodies);
double calcular_momento_angular(const std::array<Body, number_bodies> &bodies);

int main() {
  const float radius = 2;
  std::array<Body, number_bodies> bodies;

  for (auto &body : bodies) {
    body = Body();
    body.random_position(width, height);
  }

  sf::RenderWindow window(sf::VideoMode(width, height), "n-Bodies");
  window.setFramerateLimit(60);

  // Configurar fuente para el texto
  sf::Font font;
  font.loadFromFile(
      "/usr/share/fonts/jetbrains-mono/JetBrainsMonoNerdFont-Italic.ttf");
  sf::Text energyText;
  energyText.setFont(font);
  energyText.setCharacterSize(14);
  energyText.setFillColor(sf::Color::White);
  energyText.setPosition(10, 10);

  sf::Text angularMomentumText;
  angularMomentumText.setFont(font);
  angularMomentumText.setCharacterSize(14);
  angularMomentumText.setFillColor(sf::Color::White);
  angularMomentumText.setPosition(10, 30);

  std::array<sf::CircleShape, number_bodies> circles;
  std::random_device rd;
  std::mt19937 gen(rd());
  std::uniform_int_distribution<int> dist(0, 255);

  for (auto &circle : circles) {
    circle = sf::CircleShape(radius);
    sf::Color random_color(dist(gen), dist(gen), dist(gen));
    circle.setFillColor(random_color);
  }

  while (window.isOpen()) {
    sf::Event event;
    while (window.pollEvent(event)) {
      if (event.type == sf::Event::Closed)
        window.close();
    }

    window.clear(sf::Color::Black);

    // Múltiples pasos de física por frame
    for (int step = 0; step < 10; ++step) {
      calcular(bodies);
    }

    // Calcular conservación
    double energia_total = calcular_energia_total(bodies);
    double momento_angular = calcular_momento_angular(bodies);

    // Actualizar textos
    std::ostringstream oss_energy;
    oss_energy << std::fixed << std::setprecision(2)
               << "Energia Total: " << energia_total;
    energyText.setString(oss_energy.str());

    std::ostringstream oss_momentum;
    oss_momentum << std::fixed << std::setprecision(2)
                 << "Momento Angular: " << momento_angular;
    angularMomentumText.setString(oss_momentum.str());

    // Dibujar cuerpos
    for (int i = 0; i < number_bodies; ++i) {
      circles[i].setPosition(bodies[i].position[0],
                             height - bodies[i].position[1]);
      window.draw(circles[i]);
    }

    // Dibujar textos
    window.draw(energyText);
    window.draw(angularMomentumText);

    window.display();
  }
}

void calcular(std::array<Body, number_bodies> &bodies) {
  std::array<std::array<double, 2>, number_bodies> new_acc;
  std::array<std::array<double, 2>, number_bodies> new_vel;
  std::array<std::array<double, 2>, number_bodies> new_pos;

#pragma omp parallel for
  for (int i = 0; i < number_bodies; ++i) {

    std::array<double, 2> sum_forces_i = {0.0, 0.0};

    // ---- calcular fuerza sobre cuerpo i ----
    for (int j = 0; j < number_bodies; ++j) {
      if (i == j)
        continue;

      std::array<double, 2> r = bodies[j].position - bodies[i].position;
      double dist = norm_of_a_vector(r);

      if (dist > CUTTOF)
        continue;

      // estandar para softening
      double inv = 1.0 / pow(dist * dist + SOFTENING * SOFTENING, 1.5);

      // F_ij
      std::array<double, 2> f_ij =
          (GRAVITATIONAL_CONSTANT * bodies[i].mass * bodies[j].mass * inv) * r;

      sum_forces_i += f_ij;
    }

    // ---- aceleración (a = F/m) ----
    new_acc[i] = (1.0 / bodies[i].mass) * sum_forces_i;

    // ---- Euler–Cromer ----
    // v(t+dt) = v(t) + a(t)*dt
    new_vel[i] = bodies[i].velocity + DELTA_T * new_acc[i];

    // r(t+dt) = r(t) + v(t+dt) * dt
    new_pos[i] = bodies[i].position + DELTA_T * new_vel[i];
  }

  // ---- Actualizar estados ----
  for (int i = 0; i < number_bodies; ++i) {
    bodies[i].acceleration = new_acc[i];
    bodies[i].velocity = new_vel[i];
    bodies[i].position = new_pos[i];
  }
}

double calcular_energia_total(const std::array<Body, number_bodies> &bodies) {
  double energia_cinetica = 0.0;
  double energia_potencial = 0.0;

  // Energía cinética: E_k = 1/2 * m * v²
  for (int i = 0; i < number_bodies; ++i) {
    double v_squared = bodies[i].velocity[0] * bodies[i].velocity[0] +
                       bodies[i].velocity[1] * bodies[i].velocity[1];
    energia_cinetica += 0.5 * bodies[i].mass * v_squared;
  }

  // Energía potencial: E_p = -G * m1 * m2 / r
  for (int i = 0; i < number_bodies - 1; ++i) {
    for (int j = i + 1; j < number_bodies; ++j) {
      std::array<double, 2> distance_vector =
          bodies[j].position - bodies[i].position;
      double distance = norm_of_a_vector(distance_vector);

      if (distance > CUTTOF)
        continue;

      double dist_plus = distance + SOFTENING;
      energia_potencial -=
          (GRAVITATIONAL_CONSTANT * bodies[i].mass * bodies[j].mass) /
          dist_plus;
    }
  }

  return energia_cinetica + energia_potencial;
}

double calcular_momento_angular(const std::array<Body, number_bodies> &bodies) {
  double momento_angular_total = 0.0;

  // Calcular centro de masa
  std::array<double, 2> centro_masa = {0, 0};
  double masa_total = 0.0;

  for (const auto &body : bodies) {
    centro_masa[0] += body.mass * body.position[0];
    centro_masa[1] += body.mass * body.position[1];
    masa_total += body.mass;
  }

  centro_masa[0] /= masa_total;
  centro_masa[1] /= masa_total;

  // Momento angular respecto al centro de masa: L = r × p = m * (r × v)
  // En 2D: L_z = m * (x * v_y - y * v_x)
  for (const auto &body : bodies) {
    double rx = body.position[0] - centro_masa[0];
    double ry = body.position[1] - centro_masa[1];

    // Producto cruz en 2D (componente z)
    double L_z = body.mass * (rx * body.velocity[1] - ry * body.velocity[0]);
    momento_angular_total += L_z;
  }

  return momento_angular_total;
}
