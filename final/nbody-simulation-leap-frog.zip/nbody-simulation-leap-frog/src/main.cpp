#include "../include/body.hpp"
#include <SFML/Graphics.hpp>
#include <array>
#include <cmath> // Necesario para std::hypot y std::sqrt
#include <iomanip>
#include <iostream>
#include <omp.h>
#include <random>
#include <sstream>

const int number_bodies = 20;
constexpr double GRAVITATIONAL_CONSTANT = 1;
const double DELTA_T = 0.0001;
const double CUTTOF = 500;
const double SOFTENING = 1.0;
const int width = 500, height = 500;

// Declaraciones de funciones
void calcular(std::array<Body, number_bodies> &);
double calcular_energia_total(const std::array<Body, number_bodies> &bodies);
double calcular_momento_angular(const std::array<Body, number_bodies> &bodies);

int main() {
  const float radius = 2;
  std::array<Body, number_bodies> bodies;

  for (auto &body : bodies) {
    body = Body();
    body.random_position(width, height);
  }

  sf::RenderWindow window(sf::VideoMode(width, height), "n-Bodies");
  window.setFramerateLimit(60);

  // Configurar fuente para el texto
  sf::Font font;
  // Asegúrate de que esta ruta de fuente sea correcta en tu sistema
  if (!font.loadFromFile(
          "/usr/share/fonts/jetbrains-mono/JetBrainsMonoNerdFont-Italic.ttf")) {
    std::cerr << "Error cargando la fuente." << std::endl;
    return -1;
  }

  sf::Text energyText;
  energyText.setFont(font);
  energyText.setCharacterSize(14);
  energyText.setFillColor(sf::Color::White);
  energyText.setPosition(10, 10);

  sf::Text angularMomentumText;
  angularMomentumText.setFont(font);
  angularMomentumText.setCharacterSize(14);
  angularMomentumText.setFillColor(sf::Color::White);
  angularMomentumText.setPosition(10, 30);

  std::array<sf::CircleShape, number_bodies> circles;
  std::random_device rd;
  std::mt19937 gen(rd());
  std::uniform_int_distribution<int> dist(0, 255);

  for (auto &circle : circles) {
    circle = sf::CircleShape(radius);
    sf::Color random_color(dist(gen), dist(gen), dist(gen));
    circle.setFillColor(random_color);
  }

  while (window.isOpen()) {
    sf::Event event;
    while (window.pollEvent(event)) {
      if (event.type == sf::Event::Closed)
        window.close();
    }

    window.clear(sf::Color::Black);

    // Múltiples pasos de física por frame
    for (int step = 0; step < 10; ++step) {
      calcular(bodies);
    }

    // Calcular conservación
    double energia_total = calcular_energia_total(bodies);
    double momento_angular = calcular_momento_angular(bodies);

    // Actualizar textos
    std::ostringstream oss_energy;
    oss_energy << std::fixed << std::setprecision(2)
               << "Energia Total: " << energia_total;
    energyText.setString(oss_energy.str());

    std::ostringstream oss_momentum;
    oss_momentum << std::fixed << std::setprecision(2)
                 << "Momento Angular: " << momento_angular;
    angularMomentumText.setString(oss_momentum.str());

    // Dibujar cuerpos
    for (int i = 0; i < number_bodies; ++i) {
      // Nota: SFML típicamente tiene (0,0) en la esquina superior izquierda.
      // Se invierte la coordenada Y para que (0,0) sea abajo a la izquierda.
      circles[i].setPosition(bodies[i].position[0],
                             height - bodies[i].position[1]);
      window.draw(circles[i]);
    }

    // Dibujar textos
    window.draw(energyText);
    window.draw(angularMomentumText);

    window.display();
  }
  return 0;
}

void calcular(std::array<Body, number_bodies> &bodies) {

  // Usa un alias para la aceleración (F/m)
  std::array<std::array<double, 2>, number_bodies> acc;

// 1) Compute a(t) con las posiciones actuales
#pragma omp parallel for
  for (int i = 0; i < number_bodies; i++) {

    std::array<double, 2> sumF = {0.0, 0.0};

    for (int j = 0; j < number_bodies; j++) {
      if (i == j)
        continue;

      double dx = bodies[j].position[0] - bodies[i].position[0];
      double dy = bodies[j].position[1] - bodies[i].position[1];

      double dist_sq = dx * dx + dy * dy;
      double dist =
          std::sqrt(dist_sq); // Usamos sqrt solo para la comprobación CUTTOF

      if (dist > CUTTOF)
        continue; // opcional desactivable

      // Calcula el término inverso de la fuerza suavizada: 1 / (r² + ε²)^(3/2)
      double inv = 1.0 / std::pow(dist_sq + SOFTENING * SOFTENING, 1.5);

      // F = (G * m_j / (r² + ε²)^(3/2)) * r_vector
      sumF[0] += GRAVITATIONAL_CONSTANT * bodies[j].mass * inv * dx;
      sumF[1] += GRAVITATIONAL_CONSTANT * bodies[j].mass * inv * dy;
    }

    acc[i][0] = sumF[0]; // Esto es la aceleración (F/m_i)
    acc[i][1] = sumF[1];
  }

  // 2) Kick: v(t + dt/2)
  for (int i = 0; i < number_bodies; i++) {
    bodies[i].velocity[0] += 0.5 * DELTA_T * acc[i][0];
    bodies[i].velocity[1] += 0.5 * DELTA_T * acc[i][1];
  }

  // 3) Drift: r(t + dt)
  for (int i = 0; i < number_bodies; i++) {
    bodies[i].position[0] += DELTA_T * bodies[i].velocity[0];
    bodies[i].position[1] += DELTA_T * bodies[i].velocity[1];
  }

// 4) Compute a(t + dt)
#pragma omp parallel for
  for (int i = 0; i < number_bodies; i++) {

    std::array<double, 2> sumF = {0.0, 0.0};

    for (int j = 0; j < number_bodies; j++) {
      if (i == j)
        continue;

      double dx = bodies[j].position[0] - bodies[i].position[0];
      double dy = bodies[j].position[1] - bodies[i].position[1];

      double dist_sq = dx * dx + dy * dy;
      double dist = std::sqrt(dist_sq);

      if (dist > CUTTOF)
        continue;

      // Calcula el término inverso de la fuerza suavizada: 1 / (r² + ε²)^(3/2)
      double inv = 1.0 / std::pow(dist_sq + SOFTENING * SOFTENING, 1.5);

      sumF[0] += GRAVITATIONAL_CONSTANT * bodies[j].mass * inv * dx;
      sumF[1] += GRAVITATIONAL_CONSTANT * bodies[j].mass * inv * dy;
    }

    acc[i][0] = sumF[0];
    acc[i][1] = sumF[1];
  }

  // 5) Kick: v(t + dt)
  for (int i = 0; i < number_bodies; i++) {
    bodies[i].velocity[0] += 0.5 * DELTA_T * acc[i][0];
    bodies[i].velocity[1] += 0.5 * DELTA_T * acc[i][1];
  }
}

double calcular_energia_total(const std::array<Body, number_bodies> &bodies) {
  double energia_cinetica = 0.0;
  double energia_potencial = 0.0;

  // Energía cinética: E_k = 1/2 * m * v²
  for (int i = 0; i < number_bodies; ++i) {
    double v_squared = bodies[i].velocity[0] * bodies[i].velocity[0] +
                       bodies[i].velocity[1] * bodies[i].velocity[1];
    energia_cinetica += 0.5 * bodies[i].mass * v_squared;
  }

  // Energía potencial suavizada (CORRECCIÓN APLICADA AQUÍ):
  // E_p = -G * m1 * m2 / sqrt(r² + ε²)
  for (int i = 0; i < number_bodies - 1; ++i) {
    for (int j = i + 1; j < number_bodies; ++j) {
      double dx = bodies[j].position[0] - bodies[i].position[0];
      double dy = bodies[j].position[1] - bodies[i].position[1];
      double distance_sq = dx * dx + dy * dy;
      double distance = std::sqrt(distance_sq);

      if (distance > CUTTOF)
        continue;

      // Término de la energía potencial suavizada: sqrt(r² + ε²)
      double dist_soft_term = std::sqrt(distance_sq + SOFTENING * SOFTENING);

      energia_potencial -=
          (GRAVITATIONAL_CONSTANT * bodies[i].mass * bodies[j].mass) /
          dist_soft_term; // Se corrige el denominador a sqrt(r² + ε²)
    }
  }

  return energia_cinetica + energia_potencial;
}

double calcular_momento_angular(const std::array<Body, number_bodies> &bodies) {
  double momento_angular_total = 0.0;

  // Calcular centro de masa
  std::array<double, 2> centro_masa = {0, 0};
  double masa_total = 0.0;

  for (const auto &body : bodies) {
    centro_masa[0] += body.mass * body.position[0];
    centro_masa[1] += body.mass * body.position[1];
    masa_total += body.mass;
  }

  if (masa_total > 0) {
    centro_masa[0] /= masa_total;
    centro_masa[1] /= masa_total;
  }
  // Si masa_total es 0, centro_masa se mantiene en (0, 0).

  // Momento angular respecto al centro de masa: L = r × p = m * (r × v)
  // En 2D: L_z = m * (x * v_y - y * v_x)
  for (const auto &body : bodies) {
    // Coordenadas relativas al centro de masa
    double rx = body.position[0] - centro_masa[0];
    double ry = body.position[1] - centro_masa[1];

    // Producto cruz en 2D (componente z)
    double L_z = body.mass * (rx * body.velocity[1] - ry * body.velocity[0]);
    momento_angular_total += L_z;
  }

  return momento_angular_total;
}
